from django.conf.urls import url
from machine import views


app_name = 'machine'
urlpatterns = [
    url(r'^$',views.index,name='index'),
    url(r'^machine$',views.machine,name='machine'),
    url(r'^login$',views.login,name='login'),
    url(r'^home$',views.home,name='home'),
    url(r'^machine_data$',views.machine_data,name='machine_data'),
    url(r'^add$',views.add,name='add'),
    url(r'^edit$',views.edit,name='edit'),
    url(r'^delete$',views.delete,name='delete'),
    url(r'^logout$',views.logout,name='logout'),
]

