from django.apps import AppConfig


class MachineConfig(AppConfig):
    name = 'machine'
