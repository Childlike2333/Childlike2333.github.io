from django.db import models

# Create your models here.
'''
用户表:User
    usernum 账号  char 64
    username 用户名  char 64
    passwd 用户密码 char 64


机器表:Machine

    ip char 15   111.111.111.111
    user_id  Foreiginkey 指向用户表
    asset_num 资产编号 char 64
    device_location 机柜位置 char 64
    os 操作系统 char 64
    create_time    time
    update_time

'''
class User(models.Model):

    usernum = models.CharField(max_length=64,db_column='usernum')
    username = models.CharField(max_length=64, db_column='username')
    passwd = models.CharField(max_length=64, db_column='passwd')

    class Meta :
        db_table = 'user'

class Machine(models.Model):

    ip = models.CharField(max_length=16,db_column='ip')
    user_id = models.ForeignKey(User,db_column='user_id',on_delete=models.CASCADE)
    asset_num = models.CharField(max_length=64,db_column='asset_num')
    device_location = models.CharField(max_length=64, db_column='device_location')
    os = models.CharField(max_length=64, db_column='os')
    create_time = models.DateTimeField(db_column='create_time')
    update_time = models.DateTimeField(db_column='update_time')

    class Meta:
        db_table = 'machine'

