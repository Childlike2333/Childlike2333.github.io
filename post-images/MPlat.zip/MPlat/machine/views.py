from django.shortcuts import render
from django.http import JsonResponse,HttpResponseRedirect
import json
from machine.models import User,Machine
import time

# Create your views here.
def machine_data(request):

    '''
    {
        "code": 0,
        "msg": "",
        "count": 1000,
        "data": [{}, {}]
    }
    '''

    search_ip = request.GET.get('search_ip')
    if search_ip == None:
        search_ip = ''

    dict = {}
    data_list = []
    objs = Machine.objects.all()
    i = 1
    for temp_obj in objs:
        if temp_obj.ip.find(search_ip) != -1:
            temp_dict = {}
            temp_dict['id'] = i
            temp_dict['ip'] = temp_obj.ip
            temp_dict['username'] = temp_obj.user_id.username
            temp_dict['asset_num'] = temp_obj.asset_num
            temp_dict['device_location'] = temp_obj.device_location
            temp_dict['os'] = temp_obj.os
            temp_dict['create_time'] = temp_obj.create_time
            temp_dict['update_time'] = temp_obj.update_time
            i = i + 1
            data_list.append(temp_dict)
    '''
    有7条数据
    page 2
    limit 3
    
    4 5 6  [3 4 5]
    '''
    '''分页'''
    page = int(request.GET.get('page'))
    limit = int(request.GET.get('limit'))

    left = limit * (page - 1)
    right = limit * page
    data_list =data_list[left:right]

    return JsonResponse({'code':0,'msg':'','count':len(objs),'data':data_list})


def edit(request):
    old_ip = request.POST.get('old_ip')
    ip = request.POST.get('ip')
    username = request.POST.get('username')
    asset_num = request.POST.get('asset_num')
    device_location = request.POST.get('device_location')
    os = request.POST.get('os')

    old_obj = Machine.objects.get(ip=old_ip)
    print (old_ip)
    print (ip)
    if old_ip == ip:
        old_obj.user_id = User.objects.get(username=username)
        old_obj.asset_num = asset_num
        old_obj.device_location = device_location
        old_obj.os = os
        nowtime = time.strftime('%Y-%m-%d %H:%M:%S',time.localtime(time.time()))
        old_obj.update_time = nowtime
        old_obj.save()
    else:
        if len(Machine.objects.filter(ip=ip)) >= 1:
            return JsonResponse({'message': 0})
        else:
            old_obj.ip = ip
            old_obj.user_id = User.objects.get(username=username)
            old_obj.asset_num = asset_num
            old_obj.device_location = device_location
            old_obj.os = os
            nowtime = time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(time.time()))
            old_obj.update_time = nowtime
            old_obj.save()


    return JsonResponse({'message': 1})

def delete(request):

    delete_list = request.POST.get('delete_list')
    delete_list = json.loads(delete_list)
    for temp_dict in delete_list:
        Machine.objects.get(ip=temp_dict['ip']).delete()

    return JsonResponse({'message': 1})

def add(request):

    ip = request.POST.get('ip')
    if len(Machine.objects.filter(ip=ip)) >=1:
        return JsonResponse({'message':0})
    username = request.POST.get('username')
    asset_num = request.POST.get('asset_num')
    device_location = request.POST.get('device_location')
    os = request.POST.get('os')
    nowtime = time.strftime('%Y-%m-%d %H:%M:%S',time.localtime(time.time()))

    Machine.objects.create(ip=ip,
                           user_id=User.objects.get(username=username),
                           asset_num=asset_num,
                           device_location=device_location,
                           os=os,
                           create_time=nowtime,
                           update_time=nowtime).save()

    return JsonResponse({'message':1})

def home(request):
    return render(request,'home.html',{})


def index(request):

    return render(request,'index.html',{})

def machine(request):

    if request.session.get('username') == None:

        return HttpResponseRedirect('/')

    objs = User.objects.all()
    username_list = []
    for temp_obj in objs:
        username_list.append(temp_obj.username)

    return render(request,'machine/machine.html',{'username_list':username_list})

def login(request):

    field = request.POST.get('field')
    field = json.loads(field)
    usernum = field['usernum']
    passwd = field['password']

    obj = User.objects.filter(usernum=usernum)
    if len(obj) == 0:
        return JsonResponse({'message':0})
    elif obj[0].passwd != passwd:
        return JsonResponse({'message':0})
    else:

        request.session['username'] = obj[0].username

        return JsonResponse({'message':1})

def logout(request):
    request.session.flush()
    return HttpResponseRedirect('/')

