from django.contrib import admin

# Register your models here.
from machine.models import User,Machine

class UserInfoAdmin(admin.ModelAdmin):
    list_display = ['id','usernum','username','passwd']

class MachineInfoAdmin(admin.ModelAdmin):
    list_display = ['id','ip','asset_num','device_location','os','create_time','update_time']

admin.site.register(User,UserInfoAdmin)
admin.site.register(Machine,MachineInfoAdmin)